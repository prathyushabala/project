package com.virtusa.visa.VisaProcessing.service;

import com.virtusa.visa.VisaProcessing.model.Visa;
import com.virtusa.visa.VisaProcessing.repository.UserRepository;
import com.virtusa.visa.VisaProcessing.repository.VisaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class VisaImpl implements VisaSystem {

   @Autowired
   UserRepository userRepository;

   @Autowired
    VisaRepository visaRepository;

    @Override
    public void addVisaDetails( Visa userVisa){
       visaRepository.save(userVisa);
    }

    @Override
    public List<Visa> getAllPendingRequest(){
        List<Visa> pendingVisa;
        pendingVisa = visaRepository.findPendingVisas();
        return pendingVisa;
    }

    @Override
    public String getVisaStatus(String userName){
        Visa visa = visaRepository.findByUserName(userName);
        return visa.getStatus();
    }

    @Override
    public List<Visa> checkStatus(String username){
        List<Visa> statusList;
        statusList = visaRepository.userVisas(username);
        return statusList;
    }

    @Override @Transactional
    public void updateStatus(Integer visaId){
        visaRepository.alterStatus(visaId);
    }
}
