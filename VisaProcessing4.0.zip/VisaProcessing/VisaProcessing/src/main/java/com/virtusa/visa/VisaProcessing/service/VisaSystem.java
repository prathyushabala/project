package com.virtusa.visa.VisaProcessing.service;

import com.virtusa.visa.VisaProcessing.model.UserModel;
import com.virtusa.visa.VisaProcessing.model.Visa;

import java.util.List;

public interface VisaSystem {

    void addVisaDetails(Visa userVisa);

    List<Visa> getAllPendingRequest();

    String getVisaStatus(String userName);

    List<Visa> checkStatus(String username);

    void updateStatus(Integer visaId);
}
