package com.virtusa.visa.VisaProcessing.service;

import com.virtusa.visa.VisaProcessing.model.*;
import com.virtusa.visa.VisaProcessing.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserService implements UserInterface {

    @Autowired
    UserRepository userRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public boolean authenticateUser(Login login) throws Exception {
        boolean existById = this.userRepository.existsById(login.getUserName());
        if (!existById) {
            throw new Exception();
        } else {
            UserModel userModel = this.userRepository.findById(login.getUserName()).get();
            if (userModel.getPassword().contentEquals(login.getPassword())) {
                return true;
            } else {
                return false;
            }
        }
    }

    public UserModel findByUserName(String username) {
        UserModel userModel;
        userModel = userRepository.getById(username);
        return userModel;
    }

    @Override
    public void registerUser(RegisterDao userModel) throws Exception {
        boolean existId = this.userRepository.existsById(userModel.getUserName());
        if (existId) {
            throw new Exception();
        } else {
            UserModel user = new UserModel(userModel.getUserName(), userModel.getFullName(), userModel.getUserEmail(),
                    userModel.getMobNo(), bCryptPasswordEncoder.encode(userModel.getPassword()),userModel.getUserType(),
                    Collections.singletonList(new Role(userModel.getUserType())),userModel.getPassportNo());
            this.userRepository.save(user);
        }
    }

    @Override
    public  void updateProfile(String userName, RegisterDao userForm){
        UserModel userStored = userRepository.findByUserName(userName);
        userStored.setFullName(userForm.getFullName());
        userStored.setUserEmail(userForm.getUserEmail());
        userStored.setMobNo(userForm.getMobNo());
        userStored.setPassword(bCryptPasswordEncoder.encode(userForm.getPassword()));
        userRepository.save(userStored);
    }

    @Override
    public List<UserModel> empDetails() {
        List<UserModel> allEmpList;
        allEmpList = this.userRepository.allEmployeeList();
        return allEmpList;
    }

    @Override
    public List<UserModel> executives() {
        List<UserModel> allEmpList;
        allEmpList = this.userRepository.allExecutiveList();
        return allEmpList;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserModel user = userRepository.findByUserName(username);
        if (user == null) {
            throw new UsernameNotFoundException("Invalid username or password");
        }
        return new User(user.getUserName(), user.getPassword(), mapRolesToAuthorities(user.getRoles()));
    }

    private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles) {
        return roles.stream().map(role -> new SimpleGrantedAuthority((role.getName()))).collect(Collectors.toList());
    }

    @Override
    public UserModel viewProfile(String userName){
        return userRepository.findByUserName(userName);
    }

}
