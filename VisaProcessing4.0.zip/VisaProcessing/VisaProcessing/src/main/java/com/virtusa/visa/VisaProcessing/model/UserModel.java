package com.virtusa.visa.VisaProcessing.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "user")
public class UserModel {
    @Id
    private String userName;
    private String fullName ;
    private String userEmail;
    private Long mobNo;
    private String password;
    private String userType;
    @ManyToMany(fetch=FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name = "user_role",
    joinColumns = @JoinColumn(name = "userName", referencedColumnName = "userName"),
    inverseJoinColumns = @JoinColumn(name = "roleId",referencedColumnName = "id"))
    private Collection<Role> roles;
    private Long passportNo;
}
