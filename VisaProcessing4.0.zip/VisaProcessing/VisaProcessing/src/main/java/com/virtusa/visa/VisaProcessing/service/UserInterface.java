package com.virtusa.visa.VisaProcessing.service;


import com.virtusa.visa.VisaProcessing.model.Login;
import com.virtusa.visa.VisaProcessing.model.RegisterDao;
import com.virtusa.visa.VisaProcessing.model.UserModel;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserInterface extends UserDetailsService {

    boolean authenticateUser(Login login) throws Exception;

    void registerUser(RegisterDao userModel) throws Exception;

    void updateProfile(String userName, RegisterDao userForm);

    List<UserModel> empDetails();

    List<UserModel> executives();

    UserModel viewProfile(String userName);
}
