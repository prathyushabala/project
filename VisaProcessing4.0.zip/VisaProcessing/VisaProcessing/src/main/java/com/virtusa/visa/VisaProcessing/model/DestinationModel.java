package com.virtusa.visa.VisaProcessing.model;

public class DestinationModel {

    private String destination;
    private String country ;
    private int zipCode ;
    private String DOF ;
    public DestinationModel(String destination, String country, int zipCode, String dOF) {
	super();
	this.destination = destination;
	this.country = country;
	this.zipCode = zipCode;
	DOF = dOF;
    }
    public DestinationModel() {
	super();
	// TODO Auto-generated constructor stub
    }
    public String getDestination() {
        return destination;
    }
    public String getCountry() {
        return country;
    }
    public int getZipCode() {
        return zipCode;
    }
    public String getDOF() {
        return DOF;
    }
    public void setDestination(String destination) {
        this.destination = destination;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }
    public void setDOF(String dOF) {
        DOF = dOF;
    }
}
