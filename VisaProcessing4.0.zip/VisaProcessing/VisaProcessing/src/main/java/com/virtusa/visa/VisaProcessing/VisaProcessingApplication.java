package com.virtusa.visa.VisaProcessing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VisaProcessingApplication {

	public static void main(String[] args) {
		SpringApplication.run(VisaProcessingApplication.class, args);
	}

}
