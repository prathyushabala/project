package com.virtusa.visa.VisaProcessing.controller;

import com.virtusa.visa.VisaProcessing.model.Login;
import com.virtusa.visa.VisaProcessing.model.RegisterDao;
import com.virtusa.visa.VisaProcessing.model.UserModel;
import com.virtusa.visa.VisaProcessing.model.Visa;
import com.virtusa.visa.VisaProcessing.service.UserService;
import com.virtusa.visa.VisaProcessing.service.VisaSystem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private VisaSystem visaSystem;

    @GetMapping("/registration")
    public String registration(Model model) {
        model.addAttribute("userForm", new RegisterDao());
        return "registration";
    }

    @GetMapping("/profile/{username}")
    public ModelAndView profile(@PathVariable String username){
        UserModel user = userService.viewProfile(username);
        ModelAndView profile = new ModelAndView();
        profile.setViewName("profile");
        profile.addObject("user",user);
        return profile;
    }

    @PostMapping("/profile/{username}")
    public String updateProfile(@ModelAttribute("user") RegisterDao userForm, BindingResult bindingResult,@PathVariable String username){
        userService.updateProfile(username,userForm);
        return  "redirect:/logout";
    }

    @PostMapping("/registration")
    public String registration(@ModelAttribute("userForm") RegisterDao userForm, BindingResult bindingResult) throws Exception {
        if (bindingResult.hasErrors()){
            return "registration";
        }
        userService.registerUser(userForm);
        return "redirect:/login";
    }

    @GetMapping("/visastatus/{username}")
    public ModelAndView getStatus(@PathVariable String username){
        List<Visa> visaStatus;
        visaStatus = visaSystem.checkStatus(username);
        ModelAndView userVisaStatus = new ModelAndView();
        userVisaStatus.setViewName("visaStatus");
        userVisaStatus.addObject("user",visaStatus);
        return userVisaStatus;
    }

    @GetMapping("/")
    public String home(){
            return "dashboard";
    }

    @GetMapping("/logout")
    public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null){
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "redirect:/login";
    }

//    @PostMapping("/login")
//    public String login(@ModelAttribute("userLogin") Login login, BindingResult bindingResult, Model model) {
//            UserModel user = userService.findByUserName(login.getUserName());
//            model.addAttribute("user",user);
//            return "dashboard";
//    }

    @GetMapping("/dashboard")
    public String dashboard(Model model){
        return "dashboard";
    }

    @GetMapping("/allemp")
    public ModelAndView allEmpList(){
        List<UserModel> empList;
        empList = userService.empDetails();
        ModelAndView allEmpMv = new ModelAndView();
        allEmpMv.setViewName("allEmpView");
        allEmpMv.addObject("empList",empList);
        return allEmpMv;
    }
    @GetMapping("/allExecutive")
    public ModelAndView allExecutiveDetails() {
        List<UserModel> allexecutive;
        allexecutive = userService.executives();
        ModelAndView allExec = new ModelAndView();
        allExec.setViewName("allExecView");
        allExec.addObject("execList",allexecutive);
        return allExec;
    }

    @PostMapping("/applyVisa/{username}")
    public String applyForVisa(@ModelAttribute("userVisa") Visa userVisa, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            return "applyVisa";
        }
        visaSystem.addVisaDetails(userVisa);
        return "dashboard";
    }

    @GetMapping("/applyVisa/{username}")
    public String visaPage(Model model,@PathVariable String username){
        Visa visa = new Visa();
        visa.setUserName(username);
        model.addAttribute("userVisa",visa);
        return "applyVisa";
    }

    @GetMapping("/pendingRequest")
    public ModelAndView pendingReqt(){
        List<Visa> pendingRqt;
        pendingRqt = visaSystem.getAllPendingRequest();
        ModelAndView allPendingRequest = new ModelAndView();
        allPendingRequest.setViewName("pendingRequest");
        allPendingRequest.addObject("pendReqt",pendingRqt);
        return allPendingRequest;
    }

    @PostMapping("/pendingRequest")
    public String approveRequest(Integer visaId){
        System.out.println(visaId);
        visaSystem.updateStatus(visaId);
        return "redirect:/pendingRequest";
    }


}
