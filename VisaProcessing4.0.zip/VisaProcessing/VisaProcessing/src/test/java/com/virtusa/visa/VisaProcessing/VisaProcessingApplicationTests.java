package com.virtusa.visa.VisaProcessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisaProcessingApplicationTests {

	@Test
	void contextLoads() {
	}

}
